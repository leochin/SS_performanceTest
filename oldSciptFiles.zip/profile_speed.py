import time                                                     #1

import pystone_converter                                        #2

speed = {}                                                      #3

def profile_speed(function):                                    #4
    def _profile_speed(*args, **kwargs):                        #5
        start = time.clock()                                    #6
        try:
            return function(*args, **kwargs)                    #7
        finally:
            run_time = time.clock() - start                     #8
                                                                #9
            kstones = pystone_converter.kpystone_from_seconds(run_time)
            speed[function.__name__] = {'time': run_time,
                                        'kstones': kstones}     #10
    return _profile_speed                                       #11
