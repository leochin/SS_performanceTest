def add10(x):
    """ adds 10
    >>> add10(5)
    15
    >>> add10(10)
    21
    """
    return x + 10

if __name__=="__main__":
    import doctest
    doctest.testmod()
