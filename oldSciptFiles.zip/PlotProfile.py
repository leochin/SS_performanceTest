import pylab as PYLAB
from matplotlib.colors import colorConverter as CC
import numpy as NUM
import cProfile as CPROF
import pstats as PSTATS
import os as OS
from operator import itemgetter
import Utilities as UTILS
import matplotlib.cm as CM
import matplotlib.colors as COLOR 


def make_N_colors(cmap_name, N):
     cmap = CM.get_cmap(cmap_name, N)
     return cmap(NUM.arange(N)) 

def pastel(color, weight=2.4):
    """Convert color into a nice pastel shade. 
    
    SOURCE:
    Obtained from the matplotlib gallery:
    http://matplotlib.sourceforge.net/examples/pylab_examples/table_demo.html
    """

    rgb = NUM.asarray(CC.to_rgb(color))

    #### Scale Color ####
    maxC = rgb.max()
    if maxC < 1.0 and maxC > 0:
        scale = 1.0 / maxC
        rgb = rgb * scale

    #### Now Decrease Saturation ####
    total = rgb.sum()
    slack = 0
    for x in rgb:
        slack += 1.0 - x

    #### Want to Increase Weight from Total to Weight ####
    #### Pick x s.t.  slack * x == weight - total ####
    #### x = (weight - total) / slack ####
    x = (weight - total) / slack

    rgb = [c + (x * (1.0 - c)) for c in rgb]

    return rgb

def getColors(n):
    """ Return n pastel colors. """

    base = NUM.asarray([[1,0,0], [0,1,0], [0,0,1]])

    if n <= 3:
        return base[0:n]

    #### How Many New Colors Do We Need to Insert Between ####
    #### Red and Green and Between Green and Blue? ####
    needed = (((n - 3) + 1) / 2, (n - 3) / 2)

    colors = []
    for start in (0, 1):
        for x in NUM.linspace(0, 1, needed[start] + 2):
            colors.append((base[start] * (1.0 - x)) +
                           (base[start + 1] * x))

    return [pastel(c) for c in colors[0:n]]

class ProfIt:
    def __init__(self, fileName):
        self.fileName = fileName
        self.stats = PSTATS.Stats(fileName)
        self.lines = {}

    def addEntry(self, entry):
        fn, (cc, nc, tt, ct, callers) = entry
        self.lines[fn] = tt

    def sortLines(self):
        items = self.lines.items()
        items.sort(key = itemgetter(1), reverse=True)
        return items

    def report(self):
        items = self.sortLines()
        header = "Report for " + self.fileName
        cols = ["filename:lineno(function)", "total time"]
        res = [cols]
        for line in items:
            file, lineNum, fn = line[0]
            desc = file + ":" + str(lineNum) + "(" + fn + ")"
            res.append([desc, line[1]])
        outputTable = UTILS.outputTextTable(res, header = header)
        print outputTable

class PlotProfile:
    def __init__(self, file0, file1):
        self.fileNames = [file0, file1]
        self.addProfiles()

    def addProfiles(self):
        result = {}
        profiles = {}
        for file in self.fileNames:
            prof = ProfIt(file)
            p = prof.stats
            for entry in p.stats.iteritems():
                prof.addEntry(entry)
            profiles[file] = prof
        self.profiles = profiles

    def bin(self, numBins = 3, outputTextFile = None):
        colLabels = []
        rowLabels = []
        rowVals = []
        for k,prof in self.profiles.iteritems():
            prof.report()
            colLabels.append(prof.fileName)
            lines = prof.sortLines()
            rl = []
            rv = []
            maxReached = False
            c = 0
            otherTime = 0.0
            totalTime = 0.0
            for k,v in lines:
                totalTime += v
                if c < numBins:
                    file, lineNum, fn = k
                    desc = file + ":" + str(lineNum) + "(" + fn + ")"
                    rl.append(desc)
                    rv.append(v)
                else:
                    if not maxReached:
                        rl.insert(numBins, "OTHER")
                        rv.insert(numBins, v)
                        maxReached = True
                    else:
                        rv[numBins] += v
                c += 1
            rl.append("TOTAL")
            rv.append(totalTime)
            rowLabels.append(rl)
            rowVals.append(rv)
        header = "Comparison"
        row0 = ["Category for File 0"] + colLabels + ["Category for File 1"] 
        res = [ row0 ]
        file0Rows = zip(rowLabels[0], rowVals[0])
        file1Rows = zip(rowVals[1], rowLabels[1])
        for i in xrange(numBins + 2):
            newRow = [file0Rows[i][0], file0Rows[i][1], 
                      file1Rows[i][0], file1Rows[i][1]]
            res.append(newRow)

        outputTable = UTILS.outputTextTable(res, header = header)

        if outputTextFile:
            f = open(outputTextFile, "w")
            f.write(outputTable)

        data = NUM.array(zip(rowVals[0][0:-1], rowVals[1][0:-1]))
        maxTime = max([rowVals[0][-1], rowVals[1][-1]])
        dIncrement = float(maxTime / 10)
        print data

        PYLAB.axes([0.2, 0.2, 0.7, 0.6])   # leave room below the axes for the table
        rows = len(data)
        print "ROWS", rows
        colors = getColors(rows)
        #colors = make_N_colors(CM.Pastel1, rows)
        #colors = COLOR.BoundaryNorm(boundaries, rows)
        print colors
        colors.reverse()
        ind = NUM.arange(len(colLabels)) + 0.3  # the x locations for the groups
        cellText = []
        width = 0.4     # the width of the bars
        yoff = NUM.array([0.0] * len(colLabels)) # the bottom values for stacked bar chart
        for row in xrange(rows):
            PYLAB.bar(ind, data[row], width, bottom = yoff, color = colors[row])
            #yoff = yoff + data[row]
            yoff = data[row]
            cellText.append(['%0.6f' % x for x in yoff])

        ## Add a table at the bottom of the axes
        colors.reverse()
        cellText.reverse()
        the_table = PYLAB.table(cellText = cellText,
                rowLabels = rowLabels[0][0:-1], rowColours = colors,
                          colLabels = colLabels,
                          loc = 'bottom')
        PYLAB.ylabel("TIME")
        vals = NUM.arange(0, maxTime, dIncrement)
        PYLAB.yticks(vals, ['%0.6f' % val for val in vals])
        PYLAB.xticks([])
        PYLAB.title('Profile Comparison')

if __name__ == '__main__':
    file1 = "C:\TEMP\stats1.prof"
    file2 = "C:\TEMP\stats2.prof"
    pp = PlotProfile(file1, file2)
    pp.bin(outputTextFile = "C:\TEMP\CompareProf.txt")



#data = [[  66386,  174296,   75131,  577908,   32015],
#        [  58230,  381139,   78045,   99308,  160454],
#        [  89135,   80552,  152558,  497981,  603535],
#        [  78415,   81858,  150656,  193263,   69638],
#        [ 139361,  331509,  343164,  781380,   52269]]

#colLabels = ('Freeze', 'Wind', 'Flood', 'Quake', 'Hail')
#rowLabels = ['%d year' % x for x in (100, 50, 20, 10, 5)]

## Get some pastel shades for the colors
#colors = getColors(len(colLabels))
#colors.reverse()
#rows = len(data)

#ind = NUM.arange(len(colLabels)) + 0.3  # the x locations for the groups
#cellText = []
#width = 0.4     # the width of the bars
#yoff = NUM.array([0.0] * len(colLabels)) # the bottom values for stacked bar chart
#for row in xrange(rows):
#    PYLAB.bar(ind, data[row], width, bottom = yoff, color = colors[row])
#    yoff = yoff + data[row]
#    cellText.append(['%1.1f' % (x / 1000.0) for x in yoff])

## Add a table at the bottom of the axes
#colors.reverse()
#cellText.reverse()
#the_table = PYLAB.table(cellText = cellText,
#                  rowLabels = rowLabels, rowColours = colors,
#                  colLabels = colLabels,
#                  loc = 'bottom')
#PYLAB.ylabel("Loss $1000's")
#vals = NUM.arange(0, 2500, 500)
#PYLAB.yticks(vals*1000, ['%d' % val for val in vals])
#PYLAB.xticks([])
#PYLAB.title('Loss by Disaster')

#PYLAB.show()

