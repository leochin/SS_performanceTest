'''
Tool Name:  Generate Service Areas
Source Name: GenerateServiceAreas.py
Version: ArcGIS 10.1
Author: ESRI
This script generates service area polygons based on specified break values. It is intended to be used
in a geoprocessing service.
'''

#Import the modules
import os
import sys
import traceback
import time
from xml.etree import ElementTree as ET
import arcpy
import uuid
import locale

#set some constants
NA_LAYER = "GenerateServiceAreas_ServiceArea"
POLYGONS_SUBLAYER = NA_LAYER + os.sep + "Polygons"
EXTRA_BREAK_VALUE_FACTOR = 1.1
ROUND_PRECISION = 5
TIME_UNITS = ('minutes','hours','days', 'seconds')
ATTRIBUTE_PARAMETERS_FIELDS = ("AttributeName", "ParameterName", "ParameterValue")
INFINITY = sys.maxint
DEBUG = False

def print_message(message, severity=2, log_file=None):
    '''Adds a GP message based on severity. If a log file object is given, the messages is also
    written to the logfile. When writing to a file, a new line will be added to the message
    '''
    message = message.strip()
    if severity == 0:
        arcpy.AddMessage(message)
    elif severity == 1:
        arcpy.AddWarning(message)
    elif severity == 2:
        arcpy.AddError(message)
    if log_file:
        log_file.write(message)
        log_file.write("\n")

        
def convert_units(value, from_unit, to_unit):
    '''Convert values from one unit to another. value can be a list or a single number represented as 
    string. The function maintains the type for the returned value. For example, If the input value is list
    of string numbers, the output is list of converted string numbers. A single number is always returned 
    as a string as we are using floats for performing arithmetic and don't want to loose precision.
    '''
    from_unit = from_unit.lower()
    to_unit = to_unit.lower()
    #determine if the value is a list. If not we assume it is a single number passed as a number or a string.    
    isInputValueAList = isinstance(value,list)
    #if the from and to units are same, just return the original value
    if from_unit == to_unit:
        if isInputValueAList:
            #return a copy of the original list but converted to string of necessary precision
            convertedValue = [float_to_string(val, ROUND_PRECISION) for val in value]
            return convertedValue
        else:
            #make sure for a single number we always returned a string that is rounded as per global 
            #precision.
            return float_to_string(value, ROUND_PRECISION)
    #Determine if we are doing a conversion between time units or distance units    
    BASE_DISTANCE_UNIT = 'meters'
    BASE_TIME_UNIT = 'minutes'
    #python ternary operator. A if C else B
    baseUnit = BASE_TIME_UNIT if from_unit in TIME_UNITS else BASE_DISTANCE_UNIT
    #Store the constants that convert from one unit to another in a dictionary. Key is the tuple (from unit, to unit)
    #Value is the conversion constant.    
    conversionFromMeters = {('meters', 'kilometers') : 0.001,
                           ('meters', 'feet') : 3.2808399,
                           ('meters', 'miles') : 0.000621371192,
                           ('meters', 'yards') : 1.0936133,
                           ('meters', 'nautical miles') : 0.000539956803,
                           }
    conversionToMeters = {('kilometers', 'meters') : 1000.0,
                         ('feet', 'meters') : 0.3048,
                         ('miles', 'meters') : 1609.344,
                         ('yards', 'meters') : 0.9144,
                         ('nautical miles', 'meters') : 1852.0,
                         ('meters', 'meters') : 1.0
                         }
    conversionFromMinutes = {('minutes', 'hours') : 0.0166666667,
                           ('minutes', 'days') : 0.000694444444,
                           ('minutes', 'seconds') : 60.0,
                           }
    conversionToMinutes = {('hours', 'minutes') : 60.0,
                           ('days', 'minutes') : 1440.0,
                           ('seconds', 'minutes') : 0.0166666667,
                           ('minutes', 'minutes') : 1.0,
                           }
    #We first convert value in the 'from unit' to a value in the base unit and then from base unit to the to unit.        
    dictKey1 = (from_unit,baseUnit)
    dictKey2 = (baseUnit, to_unit)
    #Get the first and second conversion constants from the appropriate dicts. If key is not found use conversion
    #constant equal to 1.    
    if baseUnit == BASE_DISTANCE_UNIT:        
        firstConstantToUse = conversionToMeters.get(dictKey1,1.0)
        secondConstantToUse = conversionFromMeters.get(dictKey2,1.0)
    else:
        firstConstantToUse = conversionToMinutes.get(dictKey1,1.0)
        secondConstantToUse = conversionFromMinutes.get(dictKey2,1.0)
    #If the input value is not a list, then it must be a number    
    if isInputValueAList:
        convertedValue = []
        for val in value:
            newVal = (locale.atof(val) * firstConstantToUse) * secondConstantToUse
            convertedValue.append(float_to_string(newVal,ROUND_PRECISION))
    else:
        if isinstance(value, (str, unicode)):
            convertedValue = (locale.atof(value) * firstConstantToUse) * secondConstantToUse
        else:
            convertedValue = (float(value) * firstConstantToUse) * secondConstantToUse
        convertedValue = float_to_string(convertedValue, ROUND_PRECISION)
    return convertedValue


def get_impedance_units(useDescribe=False):
    '''Determine the units for the distance and time impedance attributes. Returns a dictionary with key as
    impedance attribute name and value as impedance units. useDescribe determines if we find the units based
    on the network dataset describe object or just use the module level variables.
    '''
    #Using module variables timeImpedance, distanceImpedance, descNDSAttributes, timeImpedanceUnits, and 
    #distanceImpedanceUnits instead of passing them as function arguments as we just need to read their 
    #values.
    impedanceUnits = {timeImpedance: '', distanceImpedance: ''}
    #If we somehow don't have impedance units, then use describe even if useDescrive is false.
    if timeImpedance:
        if not timeImpedanceUnits:
            useDescribe = True
    if distanceImpedance:
        if not distanceImpedanceUnits:
            useDescribe = True
    if useDescribe:    
        for attr in descNDSAttributes:
            # we don't want to loop through all the attributes. So if all the dict values no longer
            #contain empty strings, then break
            if all(impedanceUnits.values()):
                break
            else:
                if attr.UsageType == 'Cost':
                    if attr.name in impedanceUnits:
                        impedanceUnits[attr.name] = attr.units
    else:
        impedanceUnits[timeImpedance] = timeImpedanceUnits
        impedanceUnits[distanceImpedance] = distanceImpedanceUnits
    return impedanceUnits

def check_barriers():
    '''Checks if the input point, line and polygons barriers do not intersect more than specified
    edge features. Returns a three value boolean list (point barriers, line barriers, polygon barriers)
    indicating which barrier types should be loaded for analysis.  
    '''
    #Use the module level variables for barrier features, their counts and network dataset
    #as we are just reading the values
    #Point Line Polygons barriers
    ndsCatalogPath = descNDS.catalogPath
    barriersToLoad = [False,False,False]
    edgeFeatureClass = ""
    #Check for point barriers
    if pointBarrierCount:
        pointBarriersLyr = arcpy.management.MakeFeatureLayer(pointBarriers, "PointBarriersLayer").getOutput(0)
        if strMaxPointBarrierCount and not arcpy.na.CheckIntersectingFeatures(ndsCatalogPath, pointBarriersLyr, maxPointBarrierCount):
            barriersToLoad[0] = False
            arcpy.AddIDMessage("ERROR", 30095, "Barriers", maxPointBarrierCount)
            raise InputError()
        else:
            #we do not check how many edges are intersected by point barriers. We assume that each point
            #barrier intersects one edge            
            barriersToLoad[0] = True  
    else:
        barriersToLoad[0] = False
    #Check for line barriers
    if lineBarrierCount:
        if strMaxEdgeCountLineBarriers:
            lineBarriersLyr = arcpy.management.MakeFeatureLayer(lineBarriers, "LineBarriersLayer").getOutput(0)
            if arcpy.na.CheckIntersectingFeatures(ndsCatalogPath, lineBarriersLyr, maxEdgeCountLineBarriers):
                barriersToLoad[1] = True
            else:
                barriersToLoad[1] = False
                arcpy.AddIDMessage("ERROR", 30095, "PolylineBarriers", maxEdgeCountLineBarriers)                
                raise InputError()
        else:
            barriersToLoad[1] = True
    else:
        barriersToLoad[1] = False
    #Check for polygon barriers    
    if polygonBarrierCount:
        if strMaxEdgeCountPolygonBarriers:
            polygonBarriersLyr = arcpy.management.MakeFeatureLayer(polygonBarriers, "PolygonBarriersLayer").getOutput(0)
            if arcpy.na.CheckIntersectingFeatures(ndsCatalogPath, polygonBarriersLyr, maxEdgeCountPolygonBarriers):
                barriersToLoad[2] = True
            else:
                barriersToLoad[2] = False
                arcpy.AddIDMessage("ERROR", 30095, "PolygonBarriers", maxEdgeCountPolygonBarriers)                
                raise InputError()
        else:
            barriersToLoad[2] = True
    else:
        barriersToLoad[2] = False
    return barriersToLoad
        
            
def float_to_string(value, rounding_precision):
    '''Converts a floating point number to a string rounding off the number to the given number of digits. 
    For example, float_to_string(2.0, 5) returns 2.00000. Note that float_to_string(0, 5) returns 0.00000 
    '''
    if isinstance(value, (float,int,long)):
        floatToStringConverter = "%." + str(rounding_precision) + "f"
        return locale.format(floatToStringConverter, value)
    else:
        return value    
    #floatToStringConverter = "%." + str(rounding_precision) + "f"
    #return floatToStringConverter % float(value)

def nds_supports_hierarchy(networkAttributes):
    '''Returns a boolean indicating if a network dataset supports hierarchy. The input argument is a list of network dataset 
    attributes object obtained from network dataset describe object'''
    supportsHierarchy = True
    for attr in networkAttributes:
        if attr.usageType.lower() == 'hierarchy':
            supportsHierarchy = True
            break
    else:
        #reach here only if break statement is never reached in for loop.
        supportsHierarchy = False
    return supportsHierarchy
    
class InputError(Exception):
    '''Raise this expection whenever a throtlling condition is not met'''
    pass


#ParameterName to Parameter Index mapping. If the parameter index changes, make sure that this mapping
#is upto date.
parameterIndex = {'facilities': 0,
                  'breakValues':1,
                  'breakUnits':2,
                  'networkDataset':3,
                  'outputPolygons':4,
                  'travelDirection':5,
                  'arriveDepartTime':6,
                  'uturnPolicy':7,
                  'pointBarriers':8,
                  'lineBarriers':9,
                  'polygonBarriers':10,
                  'timeImpedance': 11,
                  'timeImpedanceUnits':12,
                  'distanceImpedance':13,
                  'distanceImpedanceUnits':14,                  
                  'useHierarchy': 15,                  
                  'restrictions':16,
                  'attributeParameters':17,
                  'searchTolerance': 18,
                  'excludeRestricted': 19,
                  'locatorWhereClause': 20,
                  'polygonMerge':21,
                  'polygonNestingType':22,
                  'detailedPolygons': 23,
                  'trimDistance' : 24,
                  'geometryPrecision':25,
                  'maxFacilities' : 26,
                  'maxBreaks': 27,
                  'maxPointBarrierCount':28,
                  'maxLineBarriers': 29,
                  'maxPolygonBarriers': 30,
                  'maxBreakTime': 31,
                  'maxBreakDistance': 32,
                  'forceHierarchyTime' : 33,
                  'forceHierarchyDistance' : 34,
                  'saveOutputLayer':35,
                  'solveSucceeded':36
                  
                  
                  }

#Get all the input and output parameter values
facilities = arcpy.GetParameter(parameterIndex['facilities'])
breakValues = arcpy.GetParameterAsText(parameterIndex['breakValues'])
breakUnits = arcpy.GetParameterAsText(parameterIndex['breakUnits'])
networkDataset = arcpy.GetParameterAsText(parameterIndex['networkDataset'])
outputPolygons = arcpy.GetParameterAsText(parameterIndex['outputPolygons'])
travelDirection = arcpy.GetParameterAsText(parameterIndex['travelDirection'])
polygonMerge = arcpy.GetParameterAsText(parameterIndex['polygonMerge'])
polygonNestingType = arcpy.GetParameterAsText(parameterIndex['polygonNestingType'])
detailedPolygons = arcpy.GetParameter(parameterIndex['detailedPolygons'])
polygonTrimDistance = arcpy.GetParameterAsText(parameterIndex['trimDistance'])
geometryPrecision = arcpy.GetParameterAsText(parameterIndex['geometryPrecision'])
uturnPolicy = arcpy.GetParameterAsText(parameterIndex['uturnPolicy'])
restrictions = arcpy.GetParameterAsText(parameterIndex['restrictions'])
useHierarchy = arcpy.GetParameter(parameterIndex['useHierarchy'])
attributeParameters = arcpy.GetParameter(parameterIndex['attributeParameters'])
pointBarriers = arcpy.GetParameter(parameterIndex['pointBarriers'])
lineBarriers = arcpy.GetParameter(parameterIndex['lineBarriers'])
polygonBarriers = arcpy.GetParameter(parameterIndex['polygonBarriers'])
arriveDepartTime = arcpy.GetParameterAsText(parameterIndex['arriveDepartTime'])
timeImpedance = arcpy.GetParameterAsText(parameterIndex['timeImpedance'])
timeImpedanceUnits = arcpy.GetParameterAsText(parameterIndex['timeImpedanceUnits'])
distanceImpedance = arcpy.GetParameterAsText(parameterIndex['distanceImpedance'])
distanceImpedanceUnits = arcpy.GetParameterAsText(parameterIndex['distanceImpedanceUnits'])
searchTolerance = arcpy.GetParameterAsText(parameterIndex['searchTolerance'])
excludeRestricted = arcpy.GetParameterAsText(parameterIndex['excludeRestricted'])
locatorWhereClause = arcpy.GetParameterAsText(parameterIndex['locatorWhereClause'])
strMaxFacilities = arcpy.GetParameterAsText(parameterIndex['maxFacilities'])
strMaxBreaks = arcpy.GetParameterAsText(parameterIndex['maxBreaks'])
strMaxPointBarrierCount = arcpy.GetParameterAsText(parameterIndex['maxPointBarrierCount'])
strMaxEdgeCountLineBarriers = arcpy.GetParameterAsText(parameterIndex['maxLineBarriers'])
strMaxEdgeCountPolygonBarriers = arcpy.GetParameterAsText(parameterIndex['maxPolygonBarriers'])
strMaxBreakTime = arcpy.GetParameterAsText(parameterIndex['maxBreakTime'])
strMaxBreakDistance = arcpy.GetParameterAsText(parameterIndex['maxBreakDistance'])
strForceHierarchyTime = arcpy.GetParameterAsText(parameterIndex['forceHierarchyTime'])
strForceHierarchyDistance = arcpy.GetParameterAsText(parameterIndex['forceHierarchyDistance'])
saveOutputLayer = arcpy.GetParameter(parameterIndex['saveOutputLayer'])

try:
    #Check out network analyst extension license
    arcpy.CheckOutExtension("network")
    #Set GP environment settings
    arcpy.env.overwriteOutput = True
    
    ##set module level variables
    solveSucceeded = False    
    useExtraBreak = False
    saLayerExists = False
    polygonType = "SIMPLE_POLYS"
    
    #Convert constraint values from strings to number. If empty string use max Int
    maxPointBarrierCount = locale.atoi(strMaxPointBarrierCount) if strMaxPointBarrierCount else INFINITY
    maxEdgeCountLineBarriers = locale.atoi(strMaxEdgeCountLineBarriers) if strMaxEdgeCountLineBarriers else INFINITY
    maxEdgeCountPolygonBarriers = locale.atoi(strMaxEdgeCountPolygonBarriers) if strMaxEdgeCountPolygonBarriers else INFINITY
    maxFacilities = locale.atoi(strMaxFacilities) if strMaxFacilities else INFINITY
    maxBreaks = locale.atoi(strMaxBreaks) if strMaxBreaks else INFINITY
    maxBreakTime = locale.atof(strMaxBreakTime) if strMaxBreakTime else INFINITY
    maxBreakDistance = locale.atof(strMaxBreakDistance) if strMaxBreakDistance else INFINITY
    forceHierarchyTime = locale.atof(strForceHierarchyTime) if strForceHierarchyTime else INFINITY
    forceHierarchyDistance = locale.atof(strForceHierarchyDistance) if strForceHierarchyDistance else INFINITY
    
    descNDS = arcpy.Describe(networkDataset)
    descNDSAttributes = descNDS.attributes
    #If the network dataset does not support hierarchy, set the useHierarchy parameter to false.
    ndsSupportsHierarchy = nds_supports_hierarchy(descNDSAttributes)
    if not ndsSupportsHierarchy:
        useHierarchy = False
    isTrimDistanceZero = False
    if not polygonTrimDistance or polygonTrimDistance.split(" ")[0] == '0':
        isTrimDistanceZero = True
    #determine whether we should use time based or distance based impedance attribute based on break units
    #using python ternary operator here.
    impedanceAttribute = timeImpedance if breakUnits.lower() in TIME_UNITS else distanceImpedance 
    #get the user supplied break values as list for easy processing    
    breakValueList = breakValues.strip().split()
    breakValueCount = len(breakValueList)
    if breakValueCount == 0:
        arcpy.AddIDMessage("ERROR",30117)
        raise InputError()
    #Find the largest break value.
    try:
        endBreakValue = max([locale.atof(val) for val in breakValueList])
    except ValueError:
        arcpy.AddIDMessage("ERROR",30118)
        raise InputError()
    impedanceUnit = get_impedance_units(False)[impedanceAttribute]
    #Convert break values from user specified units to impedance units.
    convertedBreakValueList = convert_units(breakValueList,breakUnits,impedanceUnit)
    converetedEndBreakValue = max([locale.atof(val) for val in convertedBreakValueList])   
    #Get counts for facilities, barrier features and attribute parameters
    facilityCount = int(arcpy.GetCount_management(facilities).getOutput(0))
    pointBarrierCount = int(arcpy.GetCount_management(pointBarriers).getOutput(0))
    lineBarrierCount = int(arcpy.GetCount_management(lineBarriers).getOutput(0))
    polygonBarrierCount = int(arcpy.GetCount_management(polygonBarriers).getOutput(0))
    attributeParameterCount = int(arcpy.GetCount_management(attributeParameters).getOutput(0))
    zeroString = float_to_string(0,ROUND_PRECISION)
    
    ##Determine if the throtling conditions are met. If not raise an exception and quit
    ##If throtling parameters have zero value, then do not perform throtlling checks.
    # Thortling Check 1: Check for number of facilities
    if facilityCount == 0:
        arcpy.AddIDMessage("ERROR",30117)
        raise InputError()
    if strMaxFacilities and facilityCount > maxFacilities:
        arcpy.AddIDMessage("ERROR", 30096,"Facilities", maxFacilities)
        raise InputError()
    
    #Thortling Check 2: Check for number of breaks
    if breakValueCount == 0:
        arcpy.AddIDMessage("ERROR",30117)
        raise InputError()
    if strMaxBreaks and breakValueCount > maxBreaks:
        arcpy.AddIDMessage("ERROR",30121, breakValueCount,maxBreaks)
        raise InputError()
    
    #Thortling Check 3: Check if the end break value is within maximum allowed and if hierarchy needs to be forced
    if impedanceAttribute == timeImpedance:
        if strMaxBreakTime and converetedEndBreakValue > maxBreakTime:
            convertedMaxBreakTime = convert_units(maxBreakTime,impedanceUnit,breakUnits)
            convertedMaxBreakTimeWithUnits = "%s %s" % (convertedMaxBreakTime, breakUnits)
            arcpy.AddIDMessage("ERROR",30122, endBreakValue, convertedMaxBreakTimeWithUnits)
            raise InputError()
            
        if strForceHierarchyTime and useHierarchy == False and converetedEndBreakValue > forceHierarchyTime:
            convertedForceHierarchyTime = convert_units(forceHierarchyTime, impedanceUnit, breakUnits)            
            #force to use hierarchy. If the NDS does not support hierarchy raise and error and quit.
            if ndsSupportsHierarchy:
                useHierarchy = True
                arcpy.AddIDMessage("WARNING", 30109)
                convertedForceHierarchyTimeWithUnits = "%s %s" % (convertedForceHierarchyTime, breakUnits)
                arcpy.AddIDMessage("WARNING", 30120,endBreakValue, convertedForceHierarchyTimeWithUnits)
                
            else:
                arcpy.AddIDMessage("ERROR", 30119, "Force Hierarchy beyond Break Time Value")
                raise InputError()
            
    else:
        if strMaxBreakDistance and converetedEndBreakValue > maxBreakDistance:
            convertedMaxBreakDistance = convert_units(maxBreakDistance,impedanceUnit,
                                                      breakUnits)
            convertedMaxBreakDistanceWithUnits = "%s %s" % (convertedMaxBreakDistance, breakUnits)
            arcpy.AddIDMessage("ERROR",30123, endBreakValue, convertedMaxBreakDistanceWithUnits)
            raise InputError()
        if strForceHierarchyDistance and useHierarchy == False and converetedEndBreakValue > forceHierarchyDistance:
            convertedForceHierarchyDistance = convert_units(forceHierarchyDistance, impedanceUnit, breakUnits)            
            #force to use hierarchy. If the NDS does not support hierarchy raise and error and quit.
            if ndsSupportsHierarchy:
                useHierarchy = True
                arcpy.AddIDMessage("WARNING", 30109)
                convertedForceHierarchyDistanceWithUnits = "%s %s" % (convertedForceHierarchyDistance, breakUnits)
                arcpy.AddIDMessage("WARNING", 30120,endBreakValue, convertedForceHierarchyDistanceWithUnits)
        
            else:
                arcpy.AddIDMessage("ERROR", 30119, "Force Hierarchy beyond Break Distance Value")
                raise InputError()

    #Check if generating detailed polygons when using hierarchy
    if useHierarchy and detailedPolygons:
        arcpy.AddIDMessage("ERROR", 30097, "Detailed Polygons")
        raise InputError()
    
    #Thortling Check 4: Check if the number of barrier features (point, line and polygon)
    #are within maximum allowed
    loadPointBarriers, loadLineBarriers, loadPolygonBarriers = check_barriers()    
    
    ##Perform the Service Area analysis as all throtlling conditions are met.
    #We don't want to use extra break when using hierarchy as the solver does this for us.
    #trimming is not supported when using hierarchy
    #detailed Polygons are not supported when using hierarchy
    if useHierarchy:
        useExtraBreak = False
        trimPolygons = "NO_TRIM_POLYS"
        polygonType = "SIMPLE_POLYS"
        #Add warning messages that trim distance and detailed polygons will not be generated
        if isTrimDistanceZero == False:
            arcpy.AddIDMessage("WARNING", 30097, "Polygon Trim Distance")
    else:    
        #If a trim distance is specified, we use trimming instead of extra break
        if isTrimDistanceZero == False:
            useExtraBreak = False
            trimPolygons = "TRIM_POLYS"
        else:
            useExtraBreak = True
            trimPolygons = "NO_TRIM_POLYS"
        #generate detailed polygons when requested for non-hierarchical case.
        if detailedPolygons:
            polygonType = "DETAILED_POLYS"
        else:
            polygonType = "SIMPLE_POLYS"
        
    #Add an extra break so that we get better polygons without trimming
    if useExtraBreak:
        extraBreakValue = locale.str(round(converetedEndBreakValue * EXTRA_BREAK_VALUE_FACTOR,
                                           ROUND_PRECISION))
        convertedBreakValueList.append(extraBreakValue)

    #Use only those restrictions that are supported by the network dataset. If the user supplied
    #restriction list contain un-supported restrictions, add a warning message.
    #Get a list of all the restriction attributes that the network dataset supports
    ndsRestrictions = [attribute.name for attribute in descNDSAttributes
                       if attribute.usageType == 'Restriction']
    ndsRestrictionsSet = set(ndsRestrictions)
    #ensure that we do not have single quotes in multi word restriction names
    #For example split will give us "'Non-routeable Segments'" but we need "Non-routeable Segments"
    restrictionsSet = set([x.lstrip("'").rstrip("'") for x in restrictions.split(";")])
    restrictionsToUseSet = restrictionsSet.intersection(ndsRestrictionsSet)
    unusedRestrictions = list(restrictionsSet - restrictionsToUseSet) 
    if unusedRestrictions:
        arcpy.AddIDMessage("WARNING", 30113, ", ".join(unusedRestrictions))
    #Make a new service area layer
    saLayer = arcpy.na.MakeServiceAreaLayer(networkDataset, NA_LAYER, impedanceAttribute, travelDirection,
                                  " ".join(convertedBreakValueList),polygonType, polygonMerge,
                                  polygonNestingType,"NO_LINES","OVERLAP","NO_SPLIT", "", "", uturnPolicy,
                                  list(restrictionsToUseSet), trimPolygons, polygonTrimDistance,
                                  "NO_LINES_SOURCE_FIELDS", useHierarchy, arriveDepartTime).getOutput(0)
    saLayerExists = True
    naClassNames = arcpy.na.GetNAClassNames(saLayer)
    saLayerSolverProps = arcpy.na.GetSolverProperties(saLayer)
    #Add attribute parameters if specified
    if attributeParameterCount:
        #if the record set does not have necessary fields, raise and error message and quit
        attributeParametersFieldNames = set([f.name for f in arcpy.ListFields(attributeParameters)])
        requiredAttributeParameterFieldNames = set(ATTRIBUTE_PARAMETERS_FIELDS)
        if not requiredAttributeParameterFieldNames.issubset(attributeParametersFieldNames):
            arcpy.AddIDMessage("ERROR", 30108, "Attribute Parameter Values")
            raise InputError()
        layerAttributeParameters = saLayerSolverProps.attributeParameters
        with arcpy.da.SearchCursor(attributeParameters, ATTRIBUTE_PARAMETERS_FIELDS) as cursor:
            for row in cursor:
                attributeName, attributeParameterName, attributeParameterValue = row
                key = (attributeName, attributeParameterName)
                if layerAttributeParameters is None or not key in layerAttributeParameters:
                    arcpy.AddIDMessage("WARNING", 30114, attributeName, attributeParameterName)
                    continue
                if not attributeParameterValue == None:
                    if attributeParameterValue.lower() == "none":
                        attributeParameterValue = ""
                    layerAttributeParameters[key] = attributeParameterValue
        if layerAttributeParameters:
            try:
                saLayerSolverProps.attributeParameters = layerAttributeParameters
            except ValueError as ex:
                print_message(str(ex),2)
                raise 

    #Add Barriers before loading facilities as we want to exclude restricted portions
    if loadPointBarriers:
        #If we have added cost point barriers, convert the AdditionalCost value from break units to 
        #Impedance units. The where clause is to avoid the conversion for restriction barriers.
        fieldsList = arcpy.ListFields(pointBarriers)
        fieldNamesList = [f.name for f in fieldsList]        
        naClass = naClassNames["Barriers"]
        fieldMappings = arcpy.na.NAClassFieldMappings(saLayer, naClass, False, fieldsList)
        if "BarrierType" in fieldNamesList and "AdditionalCost" in fieldNamesList:
            with arcpy.da.UpdateCursor(pointBarriers, "AdditionalCost", '"BarrierType" = 2') as cursor:
                for row in cursor:
                    addedCost = float_to_string(row[0],ROUND_PRECISION)
                    #Convert only if the cost is not equal to zero.            
                    if addedCost != zeroString:
                        newAddedCost = convert_units(addedCost,breakUnits, impedanceUnit)
                        row[0] = newAddedCost
                        cursor.updateRow(row)
        else:
            fieldMappings["BarrierType"].defaultValue = 0
        
        fieldMappings["Attr_" + impedanceAttribute].mappedFieldName = "AdditionalCost"
        arcpy.na.AddLocations(saLayer, naClass, pointBarriers, fieldMappings, searchTolerance,
                              search_query=locatorWhereClause)
    if loadLineBarriers:        
        arcpy.na.AddLocations(saLayer,naClassNames["PolylineBarriers"], lineBarriers, "#", searchTolerance,
                              search_query=locatorWhereClause)
    if loadPolygonBarriers:
        naClass = naClassNames["PolygonBarriers"]
        fieldsList = arcpy.ListFields(polygonBarriers)
        fieldMappings = arcpy.na.NAClassFieldMappings(saLayer, naClass, False, fieldsList)
        fieldMappings["Attr_" + impedanceAttribute].mappedFieldName = "ScaledCostFactor"
        arcpy.na.AddLocations(saLayer, naClass, polygonBarriers, fieldMappings, searchTolerance,
                              search_query=locatorWhereClause)
    #Add facilities
    arcpy.na.AddLocations(saLayer, naClassNames["Facilities"], facilities, "#", searchTolerance,
                          exclude_restricted_elements=excludeRestricted, search_query=locatorWhereClause)
    #Solve
    solveResult = arcpy.na.Solve(saLayer,"SKIP","TERMINATE", geometryPrecision)
    polygonsSublayer = arcpy.mapping.ListLayers(saLayer,naClassNames["SAPolygons"])[0]
    if solveResult.getOutput(1).lower() == 'true':
        solveSucceeded = True
    else:
        solveSucceeded = False
    if solveResult.maxSeverity == 1:
        print_message(solveResult.getMessages(1), 1)
    #Save the output layer. The layer name is based on random guid    
    if saveOutputLayer:
        scratchFolder = arcpy.env.scratchFolder
        uid = str(uuid.uuid4()).replace("-","")
        naLayerFileName = "_ags_gpna{0}.lyr".format(uid)
        outputLayerFile = os.path.join(scratchFolder, naLayerFileName)
        arcpy.management.SaveToLayerFile(saLayer,outputLayerFile)
        arcpy.AddIDMessage("INFORMATIVE", 30124, naLayerFileName) 
    #If we are using an extra break exlcude the polygons corresponding to that break before copying them
    if useExtraBreak:
        #We are not converting the float to str using locale specific locale.str as
        #SQL statements need number with period as decimal points irrespective of locales.
        whereClause = '"ToBreak" <= ' + str(converetedEndBreakValue)
        arcpy.management.SelectLayerByAttribute(polygonsSublayer, "NEW_SELECTION", whereClause)
    #Convert break values from impedance units to break units in the polygons sublayer.
    #We need to update the Name, FromBreak and ToBreak Fields
    if breakUnits.lower() != impedanceUnit.lower():
        nameField = "Name"        
        fromBreakField = "FromBreak"
        toBreakField = "ToBreak"
        with arcpy.da.UpdateCursor(polygonsSublayer, (nameField, fromBreakField, toBreakField)) as cursor:
            for row in cursor:
                nameFirstPart = row[0].split(":")[0].strip()
                fromBreak = float_to_string(row[1], ROUND_PRECISION)
                newFromBreak = "0"
                toBreak = float_to_string(row[2], ROUND_PRECISION)
                newToBreak = ""
                #update FromBreak value if it not zero.
                if fromBreak != zeroString:        
                    if fromBreak in convertedBreakValueList:
                        #Get the user break value which must be at the same index as the impedance break value. 
                        newFromBreak = breakValueList[convertedBreakValueList.index(fromBreak)]
                    else:
                        #This might happen if the solver could not reach the break value and the output polygons
                        #are different than the input break values. So just do a conversion
                        newFromBreak = convert_units(fromBreak, impedanceUnit, breakUnits) 
                    row[1] = newFromBreak
                #Update ToBreak value
                if toBreak in convertedBreakValueList:
                    newToBreak = breakValueList[convertedBreakValueList.index(toBreak)]
                else:
                    newToBreak = convert_units(toBreak, impedanceUnit, breakUnits)
                row[2] = newToBreak
                #update Name value
                newName = "%s : %s - %s" % (nameFirstPart, newFromBreak, newToBreak)
                row[0] = newName
                cursor.updateRow(row)
    #Copy the polygons to the output feature class
    arcpy.CopyFeatures_management(polygonsSublayer, outputPolygons)
    
except InputError as ex:
    #Handle errors due to throtling conditions
    solveSucceeded = False
    if ex.message:
        print_message(ex.message)
except arcpy.ExecuteError:
    #Handle GP exceptions
    solveSucceeded = False    
    if DEBUG:
        #Get the line number at which the GP error occured
        tb = sys.exc_info()[2]
        print_message("A geoprocessing error occured in File %s, line %s" % (__file__, tb.tb_lineno))
    else:
        print_message("A geoprocessing error occured.")
    warningMessages = arcpy.GetMessages(1) 
    if warningMessages:    
        print_message(warningMessages, 1)
    print_message(arcpy.GetMessages(2))
except:
    #Handle python errors
    solveSucceeded = False
    if DEBUG:
        #Get a nicely formatted traceback object except the first line.
        msgs = traceback.format_exception(*sys.exc_info())[1:]
        msgs[0] = "A python error occured in " + msgs[0].lstrip()
        for msg in msgs:
            print_message(msg.strip())
    else:
        print_message("A python error occured.")
finally:
    #Delete the in-memory na layer
    if saLayerExists:
        try:
            arcpy.management.Delete(saLayer)
        except:
            pass
    arcpy.SetParameter(parameterIndex['solveSucceeded'], solveSucceeded)



                  
                  
