"""
Tool Name:     Generate Spatial Weights Matrix 
Source Name:   Weights.py
Version:       ArcGIS 10.0
Author:        Environmental Systems Research Institute Inc.
Description:   Creates spatial weights in SWM format:
               
               Header Information:
                    MasterField (str)
                    Row Standard (boolean)
                    N (int) # of observations in W

               Weight Information comes in the form of four seperate
               arrays of information for each record:
                    Unique_ID (int), Number of Neighbors (int)
                    Neighbors IDs (array of ints)
                    Weights (array of floats)
                    SumWeights (float) [unstandardized sum]
"""

################### Imports ########################
import os as OS
import sys as SYS
import numpy as NUM
import locale as LOCALE
import arcpy as ARCPY
import arcpy.da as DA
import ErrorUtils_102 as ERROR
import SSUtilities_102 as UTILS
import WeightsUtilities_102 as WU
import SSDataObject_102 as SSDO 
import gapy as GAPY
import SSTimeUtilities_102 as TUTILS

################### GUI Interface ######################
def setupWeights():
    """Retrieves the parameters from the User Interface and executes the
    appropriate commands."""

    inputFC = ARCPY.GetParameterAsText(0)      
    masterField = ARCPY.GetParameterAsText(1)
    swmFile = ARCPY.GetParameterAsText(2)
    spaceConcept = ARCPY.GetParameterAsText(3)
    distanceConcept = ARCPY.GetParameterAsText(4)
    exponent = UTILS.getNumericParameter(5)
    threshold = UTILS.getNumericParameter(6)
    kNeighs = UTILS.getNumericParameter(7)
    rowStandard = ARCPY.GetParameter(8)
    tableFile = ARCPY.GetParameterAsText(9)

    #### Assess Temporal Options ####'
    timeField = UTILS.getTextParameter(10, fieldName = True)
    timeType = UTILS.getTextParameter(11)
    timeValue = UTILS.getNumericParameter(12)

    #### Assign to appropriate spatial weights method ####
    try:
        wType = WU.weightDispatch[spaceConcept]
    except:
        ARCPY.AddIDMessage("Error", 723)
        raise SystemExit()

    #### EUCLIDEAN or MANHATTAN ####
    concept = WU.conceptDispatch[distanceConcept]
    if not kNeighs:
        kNeighs = 0

    if wType <= 1:
        #### Distance Based Weights ####
        ARCPY.AddMessage(ARCPY.GetIDMessage(84118))

        #### Set Options for Fixed vs. Inverse ####
        if wType == 0:        
            exponent = exponent
            fixed = 0
        else:
            exponent = 1
            fixed = 1
        
        #### Execute Distance-Based Weights ####
        w = distance2SWM(inputFC, swmFile, masterField, fixed = fixed, 
                         concept = concept, exponent = exponent, 
                         threshold = threshold, kNeighs = kNeighs, 
                         rowStandard = rowStandard)

    elif wType == 2:
        #### k-Nearest Neighbors Weights ####
        ARCPY.AddMessage(ARCPY.GetIDMessage(84119))
        w = kNearest2SWM(inputFC, swmFile, masterField, concept = concept,
                         kNeighs = kNeighs, rowStandard = rowStandard)

    elif wType == 3:
        #### Delaunay Triangulation Weights ####
        ARCPY.AddMessage(ARCPY.GetIDMessage(84120))
        w = delaunay2SWM(inputFC, swmFile, masterField, 
                         rowStandard = rowStandard)

    elif wType == 4:
        #### Contiguity Based Weights, Edges Only ####
        ARCPY.AddMessage(ARCPY.GetIDMessage(84121))
        w = polygon2SWM(inputFC, swmFile, masterField, concept = concept, 
                        kNeighs = kNeighs, rowStandard = rowStandard,
                        contiguityType = "ROOK")

    elif wType == 5:
        #### Contiguity Based Weights, Edges and Corners ####
        ARCPY.AddMessage(ARCPY.GetIDMessage(84122))
        w = polygon2SWM(inputFC, swmFile, masterField, concept = concept, 
                        kNeighs = kNeighs, rowStandard = rowStandard,
                        contiguityType = "QUEEN")

    elif wType == 9:
        ARCPY.AddMessage(ARCPY.GetIDMessage(84255))
        w = spaceTime2SWM(inputFC, swmFile, masterField, concept = concept,
                          threshold = threshold, rowStandard = rowStandard,
                          timeField = timeField, timeType = timeType,
                          timeValue = timeValue)

    else:
        #### Tabular Input for Weights ####
        ARCPY.AddMessage(ARCPY.GetIDMessage(84123))
        if tableFile == "" or tableFile == "#":
            ARCPY.AddIDMessage("Error", 721)
            raise SystemExit()
        else: 
            table2SWM(inputFC, masterField, swmFile, tableFile, 
                      rowStandard = rowStandard) 

################### Methods ########################

def polygon2SWM(inputFC, swmFile, masterField, 
                concept = "EUCLIDEAN", kNeighs = 0,
                rowStandard = True, contiguityType = "ROOK"):
    """Creates a sparse spatial weights matrix (SWM) based on polygon
    contiguity. 

    INPUTS: 
    inputFC (str): path to the input feature class
    swmFile (str): path to the SWM file.
    masterField (str): field in table that serves as the mapping.
    concept: {str, EUCLIDEAN}: EUCLIDEAN or MANHATTAN
    kNeighs {int, 0}: number of neighbors to return (1)
    rowStandard {bool, True}: row standardize weights?
    contiguityType {str, Rook}: {Rook = Edges Only, Queen = Edges/Vertices}

    NOTES:
    (1) kNeighs is used if polygon is not contiguous. E.g. Islands
    """

    #### Set Default Progressor for Neigborhood Structure ####
    ARCPY.SetProgressor("default", ARCPY.GetIDMessage(84143))

    #### Create SSDataObject ####
    ssdo = SSDO.SSDataObject(inputFC, templateFC = inputFC)
    cnt = UTILS.getCount(inputFC)
    ERROR.errorNumberOfObs(cnt, minNumObs = 2)

    #### Validation of Master Field ####
    verifyMaster = ERROR.checkField(ssdo.allFields, masterField, 
                                    types = [0,1])

    #### Create GA Data Structure ####
    gaTable, gaInfo = WU.gaTable(ssdo.catPath, [masterField],
                                 spatRef = ssdo.spatialRefString)

    #### Assure Enough Observations ####
    N = gaInfo[0]
    ERROR.errorNumberOfObs(N, minNumObs = 2)

    #### Assure k-Nearest is Less Than Number of Features ####
    if kNeighs >= N:
        ARCPY.AddIDMessage("ERROR", 975)
        raise SystemExit()

    #### Create Nearest Neighbor Search Type For Islands ####
    gaSearch = GAPY.ga_nsearch(gaTable)
    gaConcept = concept.lower()
    gaSearch.init_nearest(0.0, kNeighs, gaConcept)
    if kNeighs > 0:
        forceNeighbor = True
    else:
        forceNeighbor = False

    #### Create Polygon Neighbors ####
    polyNeighborDict = WU.polygonNeighborDict(inputFC, masterField, 
                                   contiguityType = contiguityType)

    #### Write Poly Neighbor List (Dict) ####
    #### Set Progressor for SWM Writing ####
    ARCPY.SetProgressor("step", ARCPY.GetIDMessage(84127), 0, N, 1)

    #### Initialize Spatial Weights Matrix File ####
    if contiguityType == "ROOK":
        wType = 4
    else:
        wType = 5

    swmWriter = WU.SWMWriter(swmFile, masterField, ssdo.spatialRefName, 
                             N, rowStandard, inputFC = inputFC,
                             wType = wType, distanceMethod = concept,
                             numNeighs = kNeighs)

    #### Keep Track of Polygons w/o Neighbors ####
    islandPolys = []
    
    #### Write Polygon Contiguity to SWM File ####
    for row in xrange(N):
        gaSearch.search_by_idx(row)
        rowInfo = gaTable[row]
        oid = rowInfo[0]
        masterID = rowInfo[2]
        neighs = polyNeighborDict[masterID]
        if neighs:
            weights = [ 1. for nh in neighs ]
            isIsland = False
        else:
            isIsland = True
            islandPolys.append(oid)
            weights = []

        #### Get Nearest Neighbor Based On Centroid Distance ####
        if isIsland and forceNeighbor:
            neighs = []
            weights = []
            for nh in gaSearch:
                neighs.append(gaTable[nh.idx][2])
                weights.append(1.0)

        #### Add Weights Entry ####
        swmWriter.swm.writeEntry(masterID, neighs, weights)

        #### Set Progress ####
        ARCPY.SetProgressorPosition()

    #### Report on Features with No Neighbors ####
    countIslands = len(islandPolys)
    if countIslands:
        islandPolys.sort()
        if countIslands > 30:
            islandPolys = islandPolys[0:30]
        
        ERROR.warningNoNeighbors(N, countIslands, islandPolys, ssdo.oidName, 
                                 forceNeighbor = forceNeighbor, 
                                 contiguity = True)

    #### Clean Up ####
    swmWriter.close()
    del gaTable

    #### Report Spatial Weights Summary ####
    swmWriter.report()

    #### Report SWM File is Large ####
    swmWriter.reportLargeSWM()

    del polyNeighborDict

def delaunay2SWM(inputFC, swmFile, masterField, rowStandard = True):
    """Creates a sparse spatial weights matrix (SWM) based on Delaunay
    Triangulation.  

    INPUTS: 
    inputFC (str): path to the input feature class
    swmFile (str): path to the SWM file.
    masterField (str): field in table that serves as the mapping.
    rowStandard {bool, True}: row standardize weights?
    """

    #### Set Default Progressor for Neigborhood Structure ####
    ARCPY.SetProgressor("default", ARCPY.GetIDMessage(84143))

    #### Create SSDataObject ####
    ssdo = SSDO.SSDataObject(inputFC, templateFC = inputFC)
    cnt = UTILS.getCount(inputFC)
    ERROR.errorNumberOfObs(cnt, minNumObs = 2)

    #### Validation of Master Field ####
    verifyMaster = ERROR.checkField(ssdo.allFields, masterField, types = [0,1])

    #### Create GA Data Structure ####
    gaTable, gaInfo = WU.gaTable(ssdo.catPath, [masterField],
                                 spatRef = ssdo.spatialRefString)

    #### Assure Enough Observations ####
    N = gaInfo[0]
    ERROR.errorNumberOfObs(N, minNumObs = 2)

    #### Process any bad records encountered ####
    numBadRecs = cnt - N
    if numBadRecs:
        badRecs = WU.parseGAWarnings(gaTable.warnings)
        err = ERROR.reportBadRecords(cnt, numBadRecs, badRecs,
                                     label = ssdo.oidName)

    #### Create Delaunay Neighbor Search Type ####
    gaSearch = GAPY.ga_nsearch(gaTable)
    gaSearch.init_delaunay()

    #### Set Progressor for Weights Writing ####
    ARCPY.SetProgressor("step", ARCPY.GetIDMessage(84127), 0, N, 1)

    #### Initialize Spatial Weights Matrix File ####
    swmWriter = WU.SWMWriter(swmFile, masterField, ssdo.spatialRefName, 
                             N, rowStandard, inputFC = inputFC,
                             wType = 3)

    #### Unique Master ID Dictionary ####
    masterDict = {}

    for row in xrange(N):
        gaSearch.search_by_idx(row)
        masterID = int(gaTable[row][2])
        if masterDict.has_key(masterID):
            ARCPY.AddIDMessage("Error", 644, masterField)
            ARCPY.AddIDMessage("Error", 643)
            raise SystemExit()
        else:
            masterDict[masterID] = 1
        neighs = []
        weights = []

        for nh in gaSearch:
            neighs.append(gaTable[nh.idx][2])
            weights.append(1.0)

        #### Add Spatial Weights Matrix Entry ####
        swmWriter.swm.writeEntry(masterID, neighs, weights) 

        #### Set Progress ####
        ARCPY.SetProgressorPosition()

    #### Clean Up ####
    swmWriter.close()
    del gaTable

    #### Report if Any Features Have No Neighbors ####
    swmWriter.reportNoNeighbors()

    #### Report Spatial Weights Summary ####
    swmWriter.report()

    #### Report SWM File is Large ####
    swmWriter.reportLargeSWM()

def kNearest2SWM(inputFC, swmFile, masterField, concept = "EUCLIDEAN", 
                 kNeighs = 1, rowStandard = True):
    """Creates a sparse spatial weights matrix (SWM) based on k-nearest
    neighbors.

    INPUTS: 
    inputFC (str): path to the input feature class
    swmFile (str): path to the SWM file.
    masterField (str): field in table that serves as the mapping.
    concept: {str, EUCLIDEAN}: EUCLIDEAN or MANHATTAN 
    kNeighs {int, 1}: number of neighbors to return
    rowStandard {bool, True}: row standardize weights?
    """

    #### Assure that kNeighs is Non-Zero ####
    if kNeighs <= 0:
        ARCPY.AddIDMessage("ERROR", 976)
        raise SystemExit()

    #### Set Default Progressor for Neigborhood Structure ####
    ARCPY.SetProgressor("default", ARCPY.GetIDMessage(84143))

    #### Create SSDataObject ####
    ssdo = SSDO.SSDataObject(inputFC, templateFC = inputFC)
    cnt = UTILS.getCount(inputFC)
    ERROR.errorNumberOfObs(cnt, minNumObs = 2)

    #### Validation of Master Field ####
    verifyMaster = ERROR.checkField(ssdo.allFields, masterField, types = [0,1])

    #### Create GA Data Structure ####
    gaTable, gaInfo = WU.gaTable(ssdo.catPath, [masterField],
                                 spatRef = ssdo.spatialRefString)

    #### Assure Enough Observations ####
    N = gaInfo[0]
    ERROR.errorNumberOfObs(N, minNumObs = 2)

    #### Process any bad records encountered ####
    numBadRecs = cnt - N
    if numBadRecs:
        badRecs = WU.parseGAWarnings(gaTable.warnings)
        err = ERROR.reportBadRecords(cnt, numBadRecs, badRecs,
                                     label = ssdo.oidName)

    #### Assure k-Nearest is Less Than Number of Features ####
    if kNeighs >= N:
        ARCPY.AddIDMessage("ERROR", 975)
        raise SystemExit()

    #### Create k-Nearest Neighbor Search Type ####
    gaSearch = GAPY.ga_nsearch(gaTable)
    gaConcept = concept.lower()
    gaSearch.init_nearest(0.0, kNeighs, gaConcept)

    #### Set Progressor for Weights Writing ####
    ARCPY.SetProgressor("step", ARCPY.GetIDMessage(84127), 0, N, 1)

    #### Initialize Spatial Weights Matrix File ####
    swmWriter = WU.SWMWriter(swmFile, masterField, ssdo.spatialRefName, 
                             N, rowStandard, inputFC = inputFC,
                             wType = 2, distanceMethod = concept,
                             numNeighs = kNeighs)

    #### Unique Master ID Dictionary ####
    masterDict = {}

    for row in xrange(N):
        gaSearch.search_by_idx(row)
        masterID = int(gaTable[row][2])
        if masterDict.has_key(masterID):
            ARCPY.AddIDMessage("Error", 644, masterField)
            ARCPY.AddIDMessage("Error", 643)
            raise SystemExit()
        else:
            masterDict[masterID] = 1
        neighs = []
        weights = []

        for nh in gaSearch:
            neighs.append(gaTable[nh.idx][2])
            weights.append(1.0)

        #### Add Spatial Weights Matrix Entry ####
        swmWriter.swm.writeEntry(masterID, neighs, weights) 
        
        #### Set Progress ####
        ARCPY.SetProgressorPosition()

    swmWriter.close()
    del gaTable

    #### Report Warning/Max Neighbors ####
    swmWriter.reportNeighInfo()

    #### Report Spatial Weights Summary ####
    swmWriter.report()

    #### Report SWM File is Large ####
    swmWriter.reportLargeSWM()

def distance2SWM(inputFC, swmFile, masterField, fixed = 0, 
                 concept = "EUCLIDEAN", exponent = 1.0, threshold = None, 
                 kNeighs = 1, rowStandard = True):
    """Creates a sparse spatial weights matrix (SWM) based on k-nearest
    neighbors.

    INPUTS: 
    inputFC (str): path to the input feature class
    swmFile (str): path to the SWM file.
    masterField (str): field in table that serves as the mapping.
    fixed (boolean): fixed (1) or inverse (0) distance? 
    concept: {str, EUCLIDEAN}: EUCLIDEAN or MANHATTAN 
    exponent {float, 1.0}: distance decay
    threshold {float, None}: distance threshold
    kNeighs (int): number of neighbors to return
    rowStandard {bool, True}: row standardize weights?
    """

    #### Create SSDataObject ####
    ssdo = SSDO.SSDataObject(inputFC, templateFC = inputFC)
    cnt = UTILS.getCount(inputFC)
    ERROR.errorNumberOfObs(cnt, minNumObs = 2)

    #### Validation of Master Field ####
    verifyMaster = ERROR.checkField(ssdo.allFields, masterField, types = [0,1])

    #### Assure No Inverse Distance if Geographic Coord System ####
    if not fixed:
        wType = 0
        WU.checkGeographicCoord(ssdo.spatialRefType, WU.wTypeDispatch[fixed])
    else:
        wType = 1

    #### Set Default Progressor for Neigborhood Structure ####
    ARCPY.SetProgressor("default", ARCPY.GetIDMessage(84143))

    #### Create GA Data Structure ####
    gaTable, gaInfo = WU.gaTable(ssdo.catPath, [masterField],
                                 spatRef = ssdo.spatialRefString)

    #### Assure Enough Observations ####
    N = gaInfo[0]
    ERROR.errorNumberOfObs(N, minNumObs = 2)

    #### Process any bad records encountered ####
    numBadRecs = cnt - N
    if numBadRecs:
        badRecs = WU.parseGAWarnings(gaTable.warnings)
        err = ERROR.reportBadRecords(cnt, numBadRecs, badRecs,
                                     label = ssdo.oidName)

    #### Set the Distance Threshold ####
    if threshold == None:
        #### Finds a Default if None Provided ####
        threshold, avgDist = WU.createThresholdDist(gaTable, concept = concept,
                                              distanceInfo = ssdo.distanceInfo)

    #### Assures that the Threshold is Appropriate ####
    gaExtent = [ LOCALE.str(i) for i in gaTable.extent ]
    gaExtent = " ".join(gaExtent)
    threshold, maxSet = WU.checkDistanceThreshold(gaExtent, threshold,
                                                  weightType = fixed)
    
    #### If the Threshold is Set to the Max ####
    #### Set to Zero for Script Logic ####
    if maxSet:
        #### All Locations are Related ####
        threshold = SYS.maxint
        if N > 500:
            ARCPY.AddIDMessage("Warning", 717)

    #### Assure k-Nearest is Less Than Number of Features ####
    if kNeighs >= N and fixed:
        ARCPY.AddIDMessage("ERROR", 975)
        raise SystemExit()

    #### Create Distance/k-Nearest Neighbor Search Type ####
    gaSearch = GAPY.ga_nsearch(gaTable)
    gaConcept = concept.lower()
    gaSearch.init_nearest(threshold, kNeighs, gaConcept)

    #### Set Progressor for Weights Writing ####
    ARCPY.SetProgressor("step", ARCPY.GetIDMessage(84127), 0, N, 1)

    #### Initialize Spatial Weights Matrix File ####
    swmWriter = WU.SWMWriter(swmFile, masterField, ssdo.spatialRefName, 
                             N, rowStandard, inputFC = inputFC,
                             wType = wType, distanceMethod = concept,
                             exponent = exponent, threshold = threshold)

    #### Unique Master ID Dictionary ####
    masterDict = {}

    for row in xrange(N):
        gaSearch.search_by_idx(row)
        masterID = int(gaTable[row][2])
        x0,y0 = gaTable[row][1]
        if masterDict.has_key(masterID):
            ARCPY.AddIDMessage("Error", 644, masterField)
            ARCPY.AddIDMessage("Error", 643)
            raise SystemExit()
        else:
            masterDict[masterID] = 1
        neighs = []
        weights = []

        for nh in gaSearch:
            neighInfo = gaTable[nh.idx]
            x1,y1 = neighInfo[1]
            
            if fixed:
                weight = 1.0
            else:
                #### Calculate Distance ####
                if concept == "EUCLIDEAN":
                    dij = WU.euclideanDistance(x0,x1,y0,y1)
                else:
                    dij = WU.manhattanDistance(x0,x1,y0,y1)

                #### Calculate Weight ####
                weight = WU.distance2Weight(dij, exponent = exponent)

            neighs.append(neighInfo[2])
            weights.append(weight)

        #### Add Spatial Weights Matrix Entry ####
        swmWriter.swm.writeEntry(masterID, neighs, weights) 

        #### Set Progress ####
        ARCPY.SetProgressorPosition()

    swmWriter.close()
    del gaTable

    #### Report Warning/Max Neighbors ####
    swmWriter.reportNeighInfo()

    #### Add Linear/Angular Unit (Distance Based Only) ####
    distanceOut = ssdo.distanceInfo.outputString
    distanceOut = [ARCPY.GetIDMessage(84344).format(distanceOut)]

    #### Report Spatial Weights Summary ####
    swmWriter.report(additionalInfo = distanceOut)

    #### Report SWM File is Large ####
    swmWriter.reportLargeSWM()

def spaceTime2SWM(inputFC, swmFile, masterField, concept = "EUCLIDEAN",
                  threshold = None, rowStandard = True,
                  timeField = None, timeType = None,
                  timeValue = None):
    """
    inputFC (str): path to the input feature class
    swmFile (str): path to the SWM file.
    masterField (str): field in table that serves as the mapping.
    concept: {str, EUCLIDEAN}: EUCLIDEAN or MANHATTAN 
    threshold {float, None}: distance threshold
    rowStandard {bool, True}: row standardize weights?
    timeField {str, None}: name of the date-time field
    timeType {str, None}: ESRI enumeration of date-time intervals
    timeValue {float, None}: value forward and backward in time
    """

    #### Assure Temporal Parameters are Set ####
    if not timeField:
        ARCPY.AddIDMessage("ERROR", 1320)
        raise SystemExit()
    if not timeType:
        ARCPY.AddIDMessage("ERROR", 1321)
        raise SystemExit()
    if not timeValue or timeValue <= 0:
        ARCPY.AddIDMessage("ERROR", 1322)
        raise SystemExit()

    #### Create SSDataObject ####
    ssdo = SSDO.SSDataObject(inputFC, templateFC = inputFC)
    cnt = UTILS.getCount(inputFC)
    ERROR.errorNumberOfObs(cnt, minNumObs = 2)
    ARCPY.SetProgressor("step", ARCPY.GetIDMessage(84001), 0, cnt, 1)

    #### Validation of Master Field ####
    verifyMaster = ERROR.checkField(ssdo.allFields, masterField, types = [0,1])
    badIDs = []

    #### Create Empty GA Table ####
    gaTable = GAPY.ga_table()

    #### Create Temporal Hash ####
    timeInfo = {}

    #### Process Field Values ####
    fieldList = [masterField, "SHAPE@XY", timeField]
    try:
        rows = DA.SearchCursor(ssdo.catPath, fieldList, "", 
                               ssdo.spatialRefString)
    except:
        ARCPY.AddIDMessage("ERROR", 204)
        raise SystemExit()

    #### Add Data to GATable and Time Dictionary ####
    for row in rows:
        badRow = False

        #### Assure Masterfield is Valid ####
        masterID = row[0]
        if masterID == None or masterID == "":
            badRow = True

        #### Assure Date/Time is Valid ####
        timeStamp = row[-1]
        if timeStamp == None or timeStamp == "":
            badRow = True

        #### Assure Centroid is Valid ####
        badXY = row[1].count(None)
        if not badXY:
            x,y = row[1]
        else:
            badRow = True

        #### Process Data ####
        if not badRow:
            if timeInfo.has_key(masterID):
                #### Assure Uniqueness ####
                ARCPY.AddIDMessage("Error", 644, masterField)
                ARCPY.AddIDMessage("Error", 643)
                raise SystemExit()
            else:
                #### Fill Date/Time Dict ####
                startDT, endDT = TUTILS.calculateTimeWindow(timeStamp, 
                                                            timeValue, 
                                                            timeType)
                timeInfo[masterID] = (timeStamp, startDT, endDT)

                #### Fill GA Table ####
                gaTable.insert(masterID, (x, y), 1.0)
        else:
            badIDs.append(masterID)

        #### Set Progress ####
        ARCPY.SetProgressorPosition()

    #### Clean Up ####
    del rows
    gaTable.flush()

    #### Total Number of Valid Features ####
    numObs = len(gaTable)

    #### Get Set of Bad IDs ####
    numBadObs = len(badIDs)
    badIDs = list(set(badIDs))
    badIDs.sort()
    badIDs = [ str(i) for i in badIDs ]
    
    #### Process any bad records encountered ####
    if numBadObs:
        ERROR.reportBadRecords(cnt, numBadObs, badIDs, label = masterField)

    #### Set the Distance Threshold ####
    if threshold == None:
        #### Finds a Default if None Provided ####
        threshold, avgDist = WU.createThresholdDist(gaTable, concept = concept,
                                              distanceInfo = ssdo.distanceInfo)

    #### Assures that the Threshold is Appropriate ####
    gaExtent = [ LOCALE.str(i) for i in gaTable.extent ]
    gaExtent = " ".join(gaExtent)
    threshold, maxSet = WU.checkDistanceThreshold(gaExtent, threshold,
                                                  weightType = 1)
    
    #### If the Threshold is Set to the Max ####
    #### Set to Zero for Script Logic ####
    if maxSet:
        #### All Locations are Related ####
        threshold = SYS.maxint
        if numObs > 500:
            ARCPY.AddIDMessage("Warning", 717)

    #### Set Default Progressor for Neigborhood Structure ####
    ARCPY.SetProgressor("default", ARCPY.GetIDMessage(84143))

    #### Create Distance Neighbor Search Type ####
    gaSearch = GAPY.ga_nsearch(gaTable)
    gaConcept = concept.lower()
    gaSearch.init_nearest(threshold, 0, gaConcept)

    #### Set Progressor for Weights Writing ####
    ARCPY.SetProgressor("step", ARCPY.GetIDMessage(84127), 0, numObs, 1)

    #### Initialize Spatial Weights Matrix File ####
    swmWriter = WU.SWMWriter(swmFile, masterField, ssdo.spatialRefName, 
                             numObs, rowStandard, inputFC = inputFC,
                             wType = 9, distanceMethod = concept,
                             threshold = threshold, timeField = timeField,
                             timeType = timeType, timeValue = timeValue)

    for row in xrange(numObs):
        gaSearch.search_by_idx(row)
        masterID = gaTable[row][0]

        #### Get Date/Time Info ####
        dt0, startDT0, endDT0 = timeInfo[masterID]

        #### Create Neigh/Weights Lists ####
        neighs = []
        weights = []

        for nh in gaSearch:
            #### Search Through Spatial Neighbors ####
            neighInfo = gaTable[nh.idx]
            neighID = neighInfo[0]

            #### Get Date/Time Info ####
            dt1, startDT1, endDT1 = timeInfo[neighID]

            #### Filter Based on Date/Time ####
            insideTimeWindow = TUTILS.isTimeNeighbor(startDT0, endDT0, dt1)
            if insideTimeWindow:
                neighs.append(neighID)
                weights.append(1.0)

        #### Add Spatial Weights Matrix Entry ####
        swmWriter.swm.writeEntry(masterID, neighs, weights) 

        #### Set Progress ####
        ARCPY.SetProgressorPosition()

    swmWriter.close()
    del gaTable

    #### Report Warning/Max Neighbors ####
    swmWriter.reportNeighInfo()

    #### Report Spatial Weights Summary ####
    swmWriter.report()

    #### Report SWM File is Large ####
    swmWriter.reportLargeSWM()

def table2SWM(inputFC, masterField, swmFile, tableFile, rowStandard = True):
    """Converts a weigths matrix in table format into SWM format.

    INPUTS:
    inputFC (str): path to the input feature class
    masterField (str): field in table that serves as the mapping.
    swmFile (str): path to the SWM file.
    tableFile (str) path to the database table
    rowStandard {bool, True}: row standardize weights?
    """

    #### Set Default Progressor for Neigborhood Structure ####
    ARCPY.SetProgressor("default", ARCPY.GetIDMessage(84123))

    #### Create SSDataObject ####
    ssdo = SSDO.SSDataObject(inputFC, templateFC = inputFC)

    #### Obtain Unique IDs from Input Feature Class ####
    ssdo.obtainData(masterField, minNumObs = 2)
    ARCPY.SetProgressor("default", ARCPY.GetIDMessage(84123))
    master2Order = ssdo.master2Order
    allMaster = master2Order.keys()
    n = ssdo.numObs

    #### Create Search Cursor for Input Weights Table ####
    neighFieldName = "NID" 
    weightFieldName = "WEIGHT"
    fieldList = [masterField, neighFieldName, weightFieldName]
    try:
        rows = DA.SearchCursor(tableFile, fieldList)
    except:
        ARCPY.AddIDMessage("Error", 722)
        raise SystemExit()

    #### Initialize Spatial Weights Matrix File ####
    swmWriter = WU.SWMWriter(swmFile, masterField, ssdo.spatialRefName, 
                             n, rowStandard, inputFC = inputFC,
                             wType = 8, inputTable = tableFile)

    #### Set Progressor for SWM Reading/Writing ####
    c = 0
    cnt = UTILS.getCount(tableFile)
    ARCPY.SetProgressor("step", ARCPY.GetIDMessage(84123), 0, cnt, 1)
    lastID = "NULL"
    neighs = []
    weights = []

    #### Process Spatial Weights ####
    for row in rows:
        masterID = row[0]

        if master2Order.has_key(masterID):
            neighID = row[1]
            weight = row[2]

            if masterID == lastID:
                #### Append to Current Record ####
                try:
                    testNeigh = master2Order[neighID]
                    neighs.append(neighID)
                    weights.append(weight)
                except:
                    #### NID Does Not Exist / Not In Selection ####
                    pass

                #### Set Progress ####
                ARCPY.SetProgressorPosition()

            else:
                #### Create New Record if not NULL ####
                if lastID != "NULL":
                    allMaster.remove(lastID)
                    swmWriter.swm.writeEntry(lastID, neighs, weights) 

                    #### Reset and Initialize Containers ####
                    neighs = [neighID]
                    weights = [weight]

                else:
                    #### Create First Record ####
                    try:
                        testNeigh = master2Order[neighID]
                        neighs.append(neighID)
                        weights.append(weight)
                    except:
                        #### NID Does Not Exist / Not In Selection ####
                        pass

                lastID = masterID

                #### Set Progress ####
                ARCPY.SetProgressorPosition()
        else:
            #### Unique Id Does Not Exist / Not In Selection ####
            ARCPY.SetProgressorPosition()

    #### Write Last Record ####
    swmWriter.swm.writeEntry(lastID, neighs, weights) 
    try:
        allMaster.remove(lastID)
    except:
        pass

    #### Set Progress ####
    ARCPY.SetProgressorPosition()

    #### Write No Neighbor Features ####
    for masterID in allMaster:
        swmWriter.swm.writeEntry(masterID, [], []) 

    #### Report Warning/Max Neighbors ####
    swmWriter.reportNeighInfo()

    #### Report Spatial Weights Summary ####
    swmWriter.report()

    #### Report SWM File is Large ####
    swmWriter.reportLargeSWM()

    #### Clean Up ####
    swmWriter.close()
    del rows

if __name__ == '__main__':
    setupWeights()
