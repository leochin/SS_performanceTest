import timeit as TI
import cProfile as CPROF
import pstats as PSTATS
import numpy as NUM

def printProfile(function):
    def _call(*a, **k):
        local = locals().copy()
        local['function'] = function
        return CPROF.runctx('function(*a, **k)', globals(), local)
    return _call

def profileString(function):
    def _call(*a, **k):
        local = locals().copy()
        local['function'] = function
        return 'function(*a, **k)', local
    return _call

def saveProfile(filename):
    def inner(function):
        def _call(*a, **k):
            local = locals().copy()
            local['function'] = function
            return CPROF.runctx('function(*a, **k)', globals(), local, filename = filename)
        return _call
    return inner

def compareProfiles(listOfFiles, outputTable = None):
    results = {}
    for pFile in listOfFiles:
        st = PSTATS.Stats(pFile)

        
        

#def saveProfile(funStr, fileName):
#    return CPROF.run(funStr, fileName)

class TestAdd:
    def __init__(self, values):
        self.values = values

    def addPE(self):
        sum = 0.0
        for i in values:
            sum += i
        self.sum = sum

    def addNUM(self):
        numValues = NUM.array(self.values)
        self.sum = numValues.sum()

    def addLIST(self):
        self.sum = sum(self.values)

def addNUM(values):
    numValues = NUM.array(values)
    return numValues.sum()

def addPE(values):
    sumVals = 0.0
    for i in values:
        sumVals += i
    return sumVals

def addTest1(values):
    res = addPE(values)
    print "Results for test1: ", res
    return res

def addTest2(values):
    res = addNUM(values)
    print "Results for test2: ", res
    return res

def test1(x, y = 1.0, z = 2):
    res = addPE([x,y,z])
    print "Results for test1: ", res
    return res

def test2(x, y = 1.0, z = 2):
    res = addNUM([x,y,z])
    print "Results for test2: ", res
    return res

if __name__ == '__main__':
    #x = 0
    #y = 5.0
    #z = 10.0
    #import PlotProfile as PP
    #import gprof2dot as GPDot

    #@printProfile
    #def test(x, y = 1.0, z = 2):
    #    res = x + y + z
    #    print "Results for test: ", res
    #    return x + y + z
    #t = test(0, y = 5.0, z = 10)

    #@saveProfile(r"C:\TEMP\SAVED")
    #def test3(x, y = 1.0, z = 2):
    #    res = sum([x, y, z])
    #    print "Results for test3: ", res
    #    return res
    #t3 = test3(0, y = 5.0, z = 10)

    import numpy.random as RAND
    testVals = RAND.random_sample(10000)
    file1 = "C:\TEMP\stats1.prof"
    file2 = "C:\TEMP\stats2.prof"
    CPROF.run('addTest1(testVals)', file1)
    CPROF.run('addTest2(testVals)', file2)
    #t1 = test1(0, y = 5.0, z = 10)
    #t2 = test2(0, y = 5.0, z = 10)
    p1 = PSTATS.Stats(file1)
    p2 = PSTATS.Stats(file2)

    #pp = PP.PlotProfile([file1, file2])

    #python -m cProfile -o stat.prof MYSCRIPY.PY [ARGS...]
    #python -m pbp.scripts.gprof2dot -f pstats -o stat.dot stat.prof
    #dot -ostat.png -Tpng stat.dot
    
    






