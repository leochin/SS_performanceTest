import time as TIME
import pystone_converter as PYCONV
import PrettyPrint as PP
from guppy import hpy
from test import pystone
import sys as SYS
import numpy as NUM
import locale as LOCALE

BENCHMARK_TIME, PYSTONES = pystone.pystones()

if SYS.platform == "win32":
    timerFun = TIME.clock
else:
    timerFun = TIME.time

def kpystone_from_seconds(seconds):
    """Convert seconds to kilo pystones.  """
    return (seconds * PYSTONES) / 1e3

def measureFunction(function, resDict, keyWord):
    def _measureFunction(*args, **kwargs):
        measurer = hpy()
        measurer.setref()
        initialMemory = measurer.heap().size
        t0 = timerFun()
        try:
            res = function(*args, **kwargs)
            return res
        finally:
            t1 = timerFun()
            diff = t1 - t0
            kstones = PYCONV.kpystone_from_seconds(diff)
            memory = measurer.heap().size - initialMemory
            resDict[keyWord] = {'time': diff,
                                'kstones': kstones,
                                'memory': memory}
    return _measureFunction

def printProfile(resDict, sortType = "time", isShelf = False):

    #### Set Title and Column Labels ####
    title = "Comparing Results: Sort by " + sortType
    res = [ ["Name", "K-Stones", "Time(s)", "Memory", "Ratio"] ]

    #### Get Sorted Order ####
    keyWords = []
    values = []
    for key, value in resDict.iteritems():
        keyWords.append(key)
        values.append(value[sortType])
    orderedInd = NUM.argsort(values)
    baseSortValue = resDict[keyWords[orderedInd[0]]][sortType]

    #### Create Output Table ####
    for ind in orderedInd:
        key = keyWords[ind]
        value = resDict[key]
        ratio = (1.0 * value[sortType]) / baseSortValue
        resRow = [key,
                  LOCALE.format("%0.6f", value['kstones']),
                  LOCALE.format("%0.6f", value['time']),
                  "%i" % value['memory'],
                  LOCALE.format("%0.4f", ratio)]
        res.append(resRow)
    table = PP.outputTextTable(res, header = title)
    return table



if __name__ == "__main__":

    resDict = {}
    n = [10, 100, 1000, 10000]

    for i in n:
        nameRange = "RegRange" + str(i)
        timeRange = measureFunction(range, resDict, nameRange)
        time1 = timeRange(10000)

        nameXRange = "XRange" + str(i)
        timeXRange = measureFunction(xrange, resDict, nameXRange)
        time2 = timeXRange(10000)

    #### Sorted by Time (Seconds) ####
    table = printProfile(resDict)
    print table
    print "\n"

    #### Sorted by k-Stones ####
    tableStones = printProfile(resDict, sortType = "kstones")
    print tableStones
    print "\n"

    #### Sorted by Memory ####
    tableMemory = printProfile(resDict, sortType = "memory")
    print tableMemory

