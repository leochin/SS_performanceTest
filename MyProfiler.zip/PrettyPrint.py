def outputTextTable(x, justify="left", header="NULL", pad = 0):
    """Provides a table as a string for pretty printing.

    INPUTS: 
    x (list of lists): rows in tables
    justify (list) or (str): justification of columns
                             a) "right" = right justify all columns
                             b) ["left", "right"] left the first, 
                                right the second.
                             c) choices: {left, right, center}
    header (str): header for your table (optional)
    pad (int): pads empty space between columns

    OUTPUT: 
    result (str): table string to be printed to either ARCPY or the 
                  interpreter.

    NOTES: All rows must have the smae number of columns.
    """

    if type(x[0]) != list:
        x = [x]
    nRows = len(x)
    nCols = len(x[0])
    rangeCol = xrange(nCols)
    if type(justify) != list:
        justify = [ justify for i in rangeCol ]
    cLengths = [ 0 for i in rangeCol ]
    strList = []
    for l in x:
        stemp = [ str(item) for item in l]
        ltemp = [ len(item) for item in stemp]
        strList.append(stemp)
        c = 0
        for place in ltemp:
            if place > cLengths[c]:
                cLengths[c] = place
            c+=1
    final = []
    headerLength = sum(cLengths)
    for l in strList:
        newRow = []
        c = 0
        for item in l:
            ls = cLengths[c]
            frmt = justify[c] 
            newString = returnAdjustedString(item,ls,frmt)
            newRow.append(newString)
            c+=1
        final.append(" ".join(newRow))
    table = "\n".join(final)
    if header != "NULL":
        header = returnAdjustedString(header,headerLength,"center")
        table = header + "\n" + table
    if pad == 1:
        table = "\n" + table + "\n"
    return table

def returnAdjustedString(xString,length,justify="left"):
    """Returns string justifed with the appropriate amount of pad and to the
    correct anchor.

    INPUTS: 
    xString (str): string to be formatted
    length (int): total length used to format and anchor
    justify (str): location of anchor

    OUTPUT: res(str): formatted xString
    """

    if justify == "right":
        res = xString.rjust(length)
    elif justify == "center":
        res = xString.center(length)
    else:
        res = xString.ljust(length)
    return res
